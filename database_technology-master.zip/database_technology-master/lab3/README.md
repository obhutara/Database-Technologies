# Lab 3

## Handing in
Submit the lab report as a pdf or a txt file. Make sure that the document mentions your LiU IDs.