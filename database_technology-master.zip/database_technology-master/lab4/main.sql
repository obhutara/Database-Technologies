-- Running this file resets the databse back to an empty but complete state, after this any of the tests can be run.
-- After each test, make sure to run this file again to ensure that the databse is empty, ready for the next test.

SOURCE q2.sql;
SOURCE q3.sql;
SOURCE q4.sql;
SOURCE q5.sql;
SOURCE q6.sql;
SOURCE q7.sql;
